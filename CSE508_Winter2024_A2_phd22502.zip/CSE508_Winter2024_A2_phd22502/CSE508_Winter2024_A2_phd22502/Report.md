# Assignment 2 - CSE508 Winter 2024
Name: Shikha Sharma  
Roll: phd22502

## Image Feature Extraction
1. Used ResNet50 embeddings for extracting the image features.
2. Very basic image preprocessing was done before feeding the images to the model. They include resizing the images to 224x224, color jitters, rotations, flips and normalizing the pixel values.
3. The inference/IR pipeline however only had resizing and normalization so that the images could be fed to the model.  
   example of plain image  
   ![example plain](examples/base_image.png)  
   example of preprocessed image  
   ![example preprocessed](examples/resnet_image.png)

## Text Feature Extraction
1. Methods similar to assignment 1 were used followed by lemmatization and stemming using the nltk library.
2. After retrieving the tokens, I calculated the TF-IDF scores for each token in the corpus.
3. I tried thresholding the tokens based on their TF-IDF scores but it didn't improve the performance of the model. Here is the sample distribution of the TF-IDF scores.
   ![tfidf](examples/tfidf.png)  
   Some of the top words with their respective IDF were 
   `
   [('workspac', 6.901737206656574), ('maximum', 6.901737206656574), ('beati', 6.901737206656574), ('win', 6.901737206656574), ('fortissimo', 6.901737206656574), ('exstra', 6.901737206656574), ('poutch', 6.901737206656574), ('vertic', 6.901737206656574), ('highlight', 6.901737206656574), ('pud', 6.901737206656574)]
   `

## Image Retrieval and Text Retrieval
1. For image retrieval, I used the cosine similarity between the image features and the query image features. The top 3 images were then returned. Again, note that the query image was preprocessed before feeding it to the model.
2. For text retrieval, I used the cosine similarity between the TF-IDF scores of the query and the corpus. The top 3 documents were then returned. Sometimes, the review did not have a well defined TF-IDF score (because of missing tokens) and hence the similarity score was 0. In such cases, I discarded the document from the retrieval.
3. The results of the retrieval are shown below.  
   1. Ground Truth  
      Text input: `Small but powerful enough. It is well made, pretty basic for a speaker.  I would probably buy another one.`  
      Image input:  
      ![gt](examples/gt_img.png)
   2. Retrievals  
    ![run1](examples/run1.png)
    ![run2](examples/run2.png)
    ![run3](examples/run3.png)
    ![run4](examples/run4.png)
    ![run5](examples/run5.png)
    ![run6](examples/run6.png)

## Conclusion
1. We can see that the image retrieval outperforms the text retrieval in most cases. This is because the image features are more robust and can capture the semantics of the image better than the text features. That is why I chose the weight of image retrieval to be `0.7` and text retrieval to be `0.3`.
2. The reason for the poor performance of the text retrieval could be the lack of a good feature extraction method. The TF-IDF scores were not very effective in capturing the semantics of the text especially the causality. In my opinion attention based embeddings in both retrieval systems would strictly outperform the current methods.
3. TFIDF embedding in testing pipeline could be easily rigged by spamming all the keywords hence directly effecting the cosine scores.
4. While, the image retrieval system could use attention because in some images the main object is not the most prominent object in the image, or there are multiple objects in the image.

## the end.